<?php 
use App\Models\SubmittedSurvey;
use App\Models\Market;
use App\Models\Survey;
?>

<table>
    <tbody>
        @if (isset($data) && count($data) > 0)
            {{-- Empty rows to offset after image --}}
                <tr><td>&nbsp;</td></tr>
                <tr><td>&nbsp;</td></tr>
                <tr><td>&nbsp;</td></tr>
                <tr><td>&nbsp;</td></tr>

                <tr>
                    <th colspan="{{ 3 + $maxMarketCount }}" style="text-align: center;">
                        <strong>{{priceCollectionHeading()}}</strong>
                    </th>
                </tr>

                <tr>
                    <th colspan="{{ 3 + $maxMarketCount }}" style="text-align: center;">
                        <strong>A Look At The {{($type)?ucwords($type):'Super Market'}} Prices</strong>
                    </th>
                </tr>

                <tr><td>&nbsp;</td></tr>
            {{-- Your actual content starts here --}}
            
            @foreach ($data as $surveyName => $data)
                <?php 
                    $surveyData = Survey::with('surveyType', 'zone')->find($data['survey_id'])
                ?>
                
                <tr> 
                    <th colspan="{{ 3 + $maxMarketCount }}" style="text-align: center; background: #ff9900;">
                        <strong>Price Collected on: {{ customt_date_format($surveyData->start_date) }}</strong>
                        
                        {{-- <strong>Price Collected on: {{ customt_date_format($surveyName) }}</strong> --}}
                    </th>
                </tr>
                {{-- <tr>
                    <th colspan="{{ 3 + $maxMarketCount }}" style="text-align: center;">
                        <strong>{{($surveyData->zone)?ucfirst($surveyData->zone->name):''}}</strong>
                    </th>
                </tr> --}}
                <tr>
                    <th>
                        <strong>Commodities</strong>
                    </th>
                    <th>
                        <strong>Brand</strong>
                    </th>
                    <th>
                        <strong>Unit</strong>
                    </th>
                    <?php 
                    $surverID = $data['survey_id'];
                    
                    $marketIds = SubmittedSurvey::where('survey_id', $surverID)->pluck('market_id')->toArray();
                    $marketIds = array_unique($marketIds);
                    $markets = Market::where('status', '1')->whereIn('id', $marketIds)->orderBy('name', 'asc')->get();
                    ?>

                    @foreach($markets as $market)
                    <th style="text-align: center;"><strong>{{ ucfirst($market->name) }} (in $)</strong></th>
                    @endforeach

                </tr>

                @foreach ($data['categories'] as $categoryName => $categoryData)
                    <tr>
                        <td colspan="{{ 3 + $maxMarketCount }}" style="text-align: center;">
                            <strong>{{ strtoupper($categoryName) }}</strong>
                        </td>
                    </tr>
                    @foreach ($categoryData->groupBy('commodity_id') as $commodityId => $commodityData)
                        @php
                            $firstRow = $commodityData->first();
                            $commodityName = $firstRow->commodity->name ?? 'N/A';
                            $uniquePrices = $commodityData->pluck('amount')->unique()->values();
                            $minPrice = $uniquePrices->min();
                            $maxPrice = $uniquePrices->max();
                            $isSamePrice = $uniquePrices->count() === 1;
                        @endphp
                        <tr>
                            <td>{{ $commodityName }}</td>
                            <td>{{ $firstRow->brand->name ?? 'N/A' }}</td>
                            <td>{{ $firstRow->unit->name ?? 'N/A' }}</td>
                            @foreach ($markets as $market)
                                @php
                                    $marketPrice = $commodityData->where('market_id', $market->id)->first();
                                @endphp
                                <td>
                                    {{ $marketPrice && $marketPrice->amount ? (float) number_format($marketPrice->amount, 2, '.', '') : '-' }}
                                </td>
                            @endforeach
                        </tr>
                    @endforeach
                @endforeach
            @endforeach
        @else
            <tr>
                <td colspan="100%">No data found</td>
            </tr>
        @endif
    </tbody>
</table>
