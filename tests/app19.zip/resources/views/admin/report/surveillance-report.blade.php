@extends('admin.layouts.app')

@section('title', @$title)

@section('content')
<style>
    canvas {
        height: 300px !important;
    }
</style>

<div class="px-3">
    <div class="container-fluid">
        <div class="row mt-3">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-body">

                        <div class="row align-items-center d-flex mb-3">
                            <div class="col-xl-8 mb-3">
                                @php 
                                    $typeName = '';
                                    if ($typeId == 1) $typeName = "Food Basket";
                                    elseif ($typeId == 2) $typeName = "Hardware and Building Materials";
                                    elseif ($typeId == 3) $typeName = "Furniture and Appliances";
                                    elseif ($typeId == 4) $typeName = "Medication";
                                @endphp
                                <h4 class="header-title mb-0 font-weight-bold">Surveillance Report {{ ($typeName) ? 'for '. $typeName : '' }}</h4>
                            </div>
                            <div class="col-xl-4 text-end">
                                @php
                                    $filtersApplied = request()->has('type_id') || request()->has('start_date') || request()->has('end_date');
                                @endphp
                                <button class="btn btn-success btn-sm" type="button" data-bs-toggle="collapse" data-bs-target="#filterBox" aria-expanded="{{ $filtersApplied ? 'false' : 'true' }}" aria-controls="filterBox">
                                    <i class="bi bi-funnel"></i> Filter
                                </button>

                                @if($filtersApplied)
                                    <a href="{{ route('admin.surveillance.report.export', [
                                        'type_id'    => request('type_id'),
                                        'start_date' => request('start_date'),
                                        'end_date'   => request('end_date'),
                                    ]) }}" class="btn btn-secondary btn-sm">
                                        <i class="fas fa-file-download"></i> Export to Excel
                                    </a>
                                @endif
                            </div>
                        </div>

                        <div class="collapse show" id="filterBox">
                            <form method="GET" class="row" id="filterForm">
                                <div class="col-md-3">
                                    <label>Survey Type</label>
                                    <select name="type_id" class="form-control">
                                        <option value="">-- All Types --</option>
                                        <option value="1" {{ $typeId == 1 ? 'selected' : '' }}>Food Basket</option>
                                        <option value="2" {{ $typeId == 2 ? 'selected' : '' }}>Hardware and Building Materials</option>
                                        <option value="3" {{ $typeId == 3 ? 'selected' : '' }}>Furniture and Appliances</option>
                                        <option value="4" {{ $typeId == 4 ? 'selected' : '' }}>Medication</option>
                                    </select>
                                    <span class="error type_id_error" style="color: red !important;
    font-size: 13px;"></span>
                                </div>

                                <div class="col-md-3">
                                    <label>Start Date</label>
                                    <input type="text" name="start_date" class="form-control datepicker"
                                           value="{{ old('start_date', $startDate ?? '') }}"
                                           placeholder="dd-mm-yyyy" autocomplete="off" style="height:38px;">
                                    <span class="error start_date_error" style="color: red !important;
    font-size: 13px;"></span>
                                </div>

                                <div class="col-md-3">
                                    <label>End Date</label>
                                    <input type="text" name="end_date" class="form-control datepicker"
                                           value="{{ old('end_date', $endDate ?? '') }}"
                                           placeholder="dd-mm-yyyy" autocomplete="off" style="height:38px;">
                                    <span class="error end_date_error" style="color: red !important;
    font-size: 13px;"></span>
                                </div>

                                <div class="col-md-3 mt-4">
                                    <button class="btn btn-success btn-sm me-2" type="submit">Search</button>
                                    <a href="{{ route('admin.surveillance.report.list') }}" class="btn btn-secondary btn-sm">Reset</a>
                                </div>
                            </form>
                        </div>

                        @if(isset($grouped) && count($grouped) > 0)
                            <div class="table-responsive mt-2">
                                <table style="width: 100%; border-collapse: collapse; font-family: Arial, sans-serif; font-size: 14px;">
                                    <thead>
                                        <tr>
                                            <th style="background-color: #D9D9D9; font-weight: bold; border: 1px solid #000; padding: 6px;">Category</th>
                                            <th style="background-color: #D9D9D9; font-weight: bold; border: 1px solid #000; padding: 6px;">Commodities</th>
                                            <th style="background-color: #D9D9D9; font-weight: bold; border: 1px solid #000; padding: 6px;">Brand</th>
                                            <th style="background-color: #D9D9D9; font-weight: bold; border: 1px solid #000; padding: 6px;">Size</th>
                                            <th style="background-color: #D9D9D9; font-weight: bold; border: 1px solid #000; padding: 6px;">Max Price</th>
                                            <th style="background-color: #D9D9D9; font-weight: bold; border: 1px solid #000; padding: 6px;">Min Price</th>
                                            <th style="background-color: #D9D9D9; font-weight: bold; border: 1px solid #000; padding: 6px;">Median</th>
                                            <th style="background-color: #D9D9D9; font-weight: bold; border: 1px solid #000; padding: 6px;">Average</th>
                                            <th style="background-color: #D9D9D9; font-weight: bold; border: 1px solid #000; padding: 6px;">Availability %</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($grouped as $categoryName => $commodities)
                                            @php $firstRow = true; $rowCount = $commodities->count(); @endphp
                                            @foreach($commodities as $data)
                                            <tr>
                                                @if($firstRow)
                                                    <td rowspan="{{ $rowCount }}" style="border: 1px solid #000; background-color: #F2F2F2; font-weight: bold; padding: 6px;">
                                                        {{ strtoupper($categoryName) }}
                                                    </td>
                                                    @php $firstRow = false; @endphp
                                                @endif
                                                <td style="border: 1px solid #000; padding: 6px;">{{ $data['commodityName'] }}</td>
                                                <td style="border: 1px solid #000; padding: 6px;">{{ $data['brandName'] }}</td>
                                                <td style="border: 1px solid #000; padding: 6px;">{{ $data['unitName'] }}</td>
                                                <td style="border: 1px solid #000; padding: 6px;">${{ number_format($data['max'], 2) }}</td>
                                                <td style="border: 1px solid #000; padding: 6px;">${{ number_format($data['min'], 2) }}</td>
                                                <td style="border: 1px solid #000; padding: 6px;">${{ number_format($data['median'], 2) }}</td>
                                                <td style="border: 1px solid #000; padding: 6px;">${{ number_format($data['avg'], 2) }}</td>
                                                <td style="border: 1px solid #000; padding: 6px;">{{ number_format($data['availability'], 2) }}%</td>
                                            </tr>
                                            @endforeach
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @else
                            @if($filtersApplied)
                                <div class="mt-3 text-center">
                                    <hr>No Record Found.<hr>
                                </div>
                            @else
                                <div class="mt-3 text-center text-danger">
                                    <hr>Please apply filters to generate the Surveillance Report.<hr>
                                </div>
                            @endif
                        @endif

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<!-- jQuery & Flatpickr -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    $(function () {
        flatpickr(".datepicker", {
            dateFormat: "d-m-Y",
            maxDate: "today",
            allowInput: true,
        });

        $('#filterForm').on('submit', function (e) {
    e.preventDefault();
    let isValid = true;
    $('.error').text('');

    let typeId = $('select[name="type_id"]').val().trim();
    let startDate = $('input[name="start_date"]').val().trim();
    let endDate = $('input[name="end_date"]').val().trim();
    const dateRegex = /^\d{2}-\d{2}-\d{4}$/;

    // Required field validation
    if (typeId === '') {
        $('.type_id_error').text('Please select a survey type.');
        isValid = false;
    }

    if (startDate === '') {
        $('.start_date_error').text('Start date is required.');
        isValid = false;
    }

    if (endDate === '') {
        $('.end_date_error').text('End date is required.');
        isValid = false;
    }

    // Date format validation
    if (startDate !== '' && !dateRegex.test(startDate)) {
        $('.start_date_error').text('Start date must be in dd-mm-yyyy format.');
        isValid = false;
    }

    if (endDate !== '' && !dateRegex.test(endDate)) {
        $('.end_date_error').text('End date must be in dd-mm-yyyy format.');
        isValid = false;
    }

    // Date comparison logic
    if (startDate !== '' && endDate !== '' && dateRegex.test(startDate) && dateRegex.test(endDate)) {
        let [sd, sm, sy] = startDate.split('-');
        let [ed, em, ey] = endDate.split('-');

        let sDate = new Date(`${sy}-${sm}-${sd}`);
        let eDate = new Date(`${ey}-${em}-${ed}`);

        if (eDate < sDate) {
            $('.end_date_error').text('End date must be after or equal to start date.');
            isValid = false;
        }
    }

    // Submit the form if all is valid
    if (isValid) {
        this.submit();
    }
});

    });
</script>
@endpush
