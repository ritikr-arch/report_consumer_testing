<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Carbon;
use App\Models\{User, Zone, Type, Survey, Market, Category, Commodity, SurveyMarket, SurveyCategory, SubmittedSurvey};
use App\Exports\SurveillanceReportExport;

class SurveillanceReportController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:submit_survey_list', ['only' => ['index']]);
        $this->middleware('permission:submit_survey_create', ['only' => ['create', 'store']]);
        $this->middleware('permission:submit_survey_edit', ['only' => ['edit', 'update', 'changeStatus']]);
        $this->middleware('permission:submit_survey_delete', ['only' => ['delete']]);
    }

 public function index(Request $request)
{
    $typeId    = $request->input('type_id');
    $startDate = $request->input('start_date');
    $endDate   = $request->input('end_date');

    $title = 'All Surveillance Report Summary';
    $grouped = [];

    // Only proceed if any filter is applied
    if ($typeId || $startDate || $endDate) {
        $submittedSurveys = SubmittedSurvey::with([
            'commodity:id,name',
            'category:id,name',
            'market:id,name',
            'zone:id,name',
            'brand:id,name',
            'unit:id,name',
            'survey:id,type_id'
        ])
        ->whereNotNull('brand_id')
        ->whereNotNull('unit_id')
        ->when($startDate, function ($query) use ($startDate) {
            $query->whereDate('created_at', '>=', Carbon::parse($startDate)->startOfDay());
        })
        ->when($endDate, function ($query) use ($endDate) {
            $query->whereDate('created_at', '<=', Carbon::parse($endDate)->endOfDay());
        })
        ->when($typeId, function ($query) use ($typeId) {
            $query->whereHas('survey', function ($q) use ($typeId) {
                $q->where('type_id', $typeId);
            });
        })
        ->get();

        $grouped = $submittedSurveys
            ->filter(fn($item) => $item->category && $item->commodity)
            ->groupBy(fn($item) => $item->category->name)
            ->map(function ($categoryItems) {
                return $categoryItems->groupBy(fn($item) => $item->commodity->id)->map(function ($commodityItems) {
                    $amounts = $commodityItems->pluck('amount')->filter()->sort()->values()->toArray();
                    $count = count($amounts);

                    $median = $count
                        ? ($count % 2
                            ? $amounts[floor($count / 2)]
                            : ($amounts[$count / 2 - 1] + $amounts[$count / 2]) / 2)
                        : 0;

                    $max = $count ? max($amounts) : 0;
                    $min = $count ? min($amounts) : 0;
                    $avg = $count ? array_sum($amounts) / $count : 0;

                    $marketCount = $commodityItems->pluck('market_id')->unique()->count();
                    $totalMarkets = $commodityItems->pluck('market_id')->count();
                    $availability = ($totalMarkets > 0) ? (($marketCount / $totalMarkets) * 100) : 0;

                    $firstItem = $commodityItems->first();

                    return [
                        'commodityName' => optional($firstItem->commodity)->name ?? 'N/A',
                        'brandName'     => optional($firstItem->brand)->name ?? 'No Name',
                        'unitName'      => optional($firstItem->unit)->name ?? 'No Unit',
                        'max'           => $max,
                        'min'           => $min,
                        'median'        => $median,
                        'avg'           => $avg,
                        'availability'  => $availability
                    ];
                });
            });
    }

    return view('admin.report.surveillance-report', compact(
        'title',
        'grouped',
        'typeId',
        'startDate',
        'endDate'
    ));
}


    public function export(Request $request)
    {
        $filters = $request->only(['type_id', 'start_date', 'end_date']);
       

        if (empty($filters['type_id']) && empty($filters['start_date']) && empty($filters['end_date'])) {
            return back()->with('error', 'Please apply at least one filter before exporting.');
        }

        return Excel::download(
    new SurveillanceReportExport($filters),
    'Surveillance_Report_' . now()->format('d-m-Y') . '.xlsx'
);
    }
}
