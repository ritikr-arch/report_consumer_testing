<p>Dear {{ucfirst($user->name)}}, </p>
<p>Your password reset OTP is: <strong>{{ $otp }}</strong></p>
<p>This OTP is valid for 10 minutes.</p>
<p>If you didn’t request this, please ignore this email.</p>
