<?php 
namespace App\Exports;

use App\Models\SubmittedSurvey;
use App\Models\Market;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\WithDrawings;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;


class StoreReportExport implements FromView, WithDrawings, WithColumnFormatting
{
    protected $data;
    protected $maxMarketCount;
    protected $markets;
    protected $type;


    public function __construct($data, $maxMarketCount, $type)
    {
        $this->data = $data;
        $this->maxMarketCount = $maxMarketCount;
        $this->type = $type;

		$surveyIds = collect($data)->pluck('survey_id')->unique()->filter();
        $marketIds = \App\Models\SubmittedSurvey::whereIn('survey_id', $surveyIds)->pluck('market_id')->unique();
        $this->markets = Market::whereIn('id', $marketIds)->where('status', 1)->get();
        
    }

    public function view(): View
    {
        if($this->type == 'medication'){
            $path = 'exports.medication_survey_export_excel';
        }else{
            $path = 'exports.survey_export_excel';
        }
        return view("$path", [
            'data' => $this->data,
            'maxMarketCount' => $this->maxMarketCount,
            'markets' => $this->markets,
            'type' =>$this->type,
        ]);
    }

    public function drawings(){
        $drawing = new Drawing();
        $drawing->setName('Logo');
        $drawing->setDescription('Company Logo');
        $drawing->setPath(public_path('admin/images/excel-logo.png'));
        $drawing->setHeight(70); 
        $drawing->setOffsetX(50); 

        if(strtolower($this->type) == 'medication'){
            $length = ((count($this->markets)*2) + 2);
        }else{
            $length = (count($this->markets) + 3);
        }

        $columnIndex = ceil( $length/ 2);
        $columnLetter = Coordinate::stringFromColumnIndex($columnIndex);

        $drawing->setCoordinates($columnLetter . '1'); // Set to row 1

        return [$drawing];
    }

    public function columnFormats(): array
    {
        $formats = [];
        foreach (range('D', 'Z') as $column) {
            $formats[$column] = \PhpOffice\PhpSpreadsheet\Style\NumberFormat::FORMAT_NUMBER_00;
        }
        return $formats;
    }

}

?>